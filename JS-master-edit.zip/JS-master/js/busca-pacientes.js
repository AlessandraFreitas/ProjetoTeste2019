var botao = document.querySelector(".busca-pacientes");

botao.addEventListener("click", function(){
    var xhr = new XMLHttpRequest();

    xhr.open("GET", "https://api-pacientes.herokuapp.com/pacientes");

    xhr.addEventListener("load", function(){
        
        if(xhr.status == 200){

            var resposta = xhr.responseText;
            var pacientes = JSON.parse(resposta);
    
            var tabela = document.querySelector("#tabela-pacientes")
    
            pacientes.forEach(function(paciente){
                var pacienteTr = montaTr(paciente);
    
                tabela.appendChild(pacienteTr);
            });
        } else {
            var erroAjax = document.querySelector(".erro-ajax");
            erroAjax.classList.remove("invisivel");
        } 
    })

    xhr.send();
})