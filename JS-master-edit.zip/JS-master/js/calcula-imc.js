var titulo = document.querySelector(".titulo");

titulo.textContent = "Aparecida Nutricionista";

var pacientes = document.querySelectorAll(".paciente");

for (var i = 0; i < pacientes.length; i++) {
    var paciente = pacientes[i];

    //ar tdPeso = paciente.querySelector(".info-peso").textContent;
    var peso = paciente.querySelector(".info-peso").textContent; //tdPeso.textContent;

    //var tdAltura = paciente.querySelector(".info-altura");
    var altura = paciente.querySelector(".info-altura").textContent;

    var tdImc = paciente.querySelector(".info-imc");

    var pesoEhValido = validaPeso(peso);
    var alturaEhValida = validaAltura(altura);

    if (!pesoEhValido) {
        tdImc.textContent = "Peso inválido";
        pesoEhValido = false;
        paciente.classList.add("paciente-invalido");
    }

    if (!alturaEhValida) {
        tdImc.textContent = "Altura inválida";
        alturaEhValida = false;
        paciente.classList.add("paciente-invalido");
    }

    console.log(altura);

    if (pesoEhValido && alturaEhValida) {
        var imc = peso / (altura * altura);
        tdImc.textContent = calculaImc(altura,peso);
        console.log(alturaEhValida);
        console.log(pesoEhValido);
    }

    console.log(imc);

}

function calculaImc(altura,peso){
    var imc = 0

    imc = imc = peso / (altura * altura);

    return imc.toFixed(2);
}

function validaPeso(peso){
    if (peso <= 0 || peso >= 1000) {
        return false;
    }else{
        return true;
    }
}

function validaAltura(altura){
    if (altura <= 0 || altura >= 3.00) {
        return false;
    }else{
        return true;
    }
}









