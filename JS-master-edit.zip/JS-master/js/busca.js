var campoBusca = document.querySelector("#campo-busca");

campoBusca.addEventListener("input", function(){

    var valorBusca = this.value;
    
    var pacientes = document.querySelectorAll(".paciente");
    
    if(valorBusca.length > 0){
        pacientes.forEach(function(paciente){

            var pacienteTd = paciente.querySelector(".info-nome");
            var nome = pacienteTd.textContent;

            var filtro = new RegExp(valorBusca, "i")

            if(filtro.test(nome)){
                paciente.classList.remove("invisivel");
            }else{
                paciente.classList.add("invisivel");
            }
        });
    }else{
        exibibePacientes(pacientes);
    }


});

function exibibePacientes(pacientes){
    pacientes.forEach(function(paciente){
        paciente.classList.remove("invisivel");
    });
}